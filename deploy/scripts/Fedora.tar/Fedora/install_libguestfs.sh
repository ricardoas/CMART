echo 'Install libguestfs for modifying the files inside VM images'

yum install -y '*guestf*'
