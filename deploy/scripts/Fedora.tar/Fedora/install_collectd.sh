echo 'Script for installing collectd - config missing? 10/26/2011, Ji Yang'

yum install -y collectd
yum install -y *collectd-virt*
