echo 'Installing openJDK for Fedora'
su -c "yum install -y java-1.6.0-openjdk"
